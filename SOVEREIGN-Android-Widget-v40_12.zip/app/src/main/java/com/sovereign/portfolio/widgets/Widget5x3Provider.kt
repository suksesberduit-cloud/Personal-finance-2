package com.sovereign.portfolio.widgets

/** Widget ukuran 5x3 — dashboard paling lengkap: semua komponen portfolio + progress BTC + dividend */
class Widget5x3Provider : BaseSovereignWidgetProvider()
