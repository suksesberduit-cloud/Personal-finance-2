package com.sovereign.portfolio

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.sovereign.portfolio.widgets.Widget2x2Provider
import com.sovereign.portfolio.widgets.Widget3x2Provider
import com.sovereign.portfolio.widgets.Widget5x2Provider
import com.sovereign.portfolio.widgets.Widget5x2DreamProgressProvider
import com.sovereign.portfolio.widgets.Widget5x3DividendProvider
import com.sovereign.portfolio.widgets.Widget5x3Provider
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val ACTION_REFRESH = "com.sovereign.portfolio.ACTION_REFRESH"

/**
 * Central renderer untuk ke-4 ukuran widget SOVEREIGN.
 * Dipanggil oleh masing-masing AppWidgetProvider.onUpdate() dan oleh
 * PriceUpdateWorker setiap kali fetch data baru selesai.
 */
object WidgetUpdater {

    private fun timeNow(): String =
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

    private fun openAppIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun refreshIntent(context: Context, providerClass: Class<*>, requestCode: Int): PendingIntent {
        val intent = Intent(context, providerClass).apply {
            action = ACTION_REFRESH
        }
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun trendIcon(chg: Double?): Int =
        if ((chg ?: 0.0) >= 0) R.drawable.ic_trend_up else R.drawable.ic_trend_down

    private fun trendColor(chg: Double?): Int =
        if ((chg ?: 0.0) >= 0) 0xFF22C55E.toInt() else 0xFFEF4444.toInt()

    private fun dotColorForPct(pct: Double): Int = when {
        pct < 100 -> 0xFFEF4444.toInt()
        pct < 120 -> 0xFFFBBF24.toInt()
        else -> 0xFF22C55E.toInt()
    }

    // ───────────────────────────────────────────────
    // ENTRY POINT — update semua instance ke-4 widget
    // ───────────────────────────────────────────────
    fun updateAll(context: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(context)
            val prices = Store.loadPrices(context)
            val portfolio = Store.loadPortfolio(context)
            val snap = PortfolioCalculator.calculate(prices, portfolio)

            renderType(context, mgr, Widget2x2Provider::class.java, R.layout.widget_2x2, R.id.widgetRoot2x2, 200) { rv ->
                bind2x2(context, rv, snap)
            }
            renderType(context, mgr, Widget3x2Provider::class.java, R.layout.widget_3x2, R.id.widgetRoot3x2, 300) { rv ->
                bind3x2(context, rv, prices)
            }
            renderType(context, mgr, Widget5x2Provider::class.java, R.layout.widget_5x2, R.id.widgetRoot5x2, 500) { rv ->
                bind5x2(context, rv, snap, prices)
            }
            renderType(context, mgr, Widget5x3Provider::class.java, R.layout.widget_5x3, R.id.widgetRoot5x3, 530) { rv ->
                bind5x3(context, rv, snap, prices)
            }
            renderType(context, mgr, Widget5x3DividendProvider::class.java, R.layout.widget_5x3_dividend, R.id.widgetRoot5x3Dividend, 560) { rv ->
                bind5x3Dividend(context, rv, prices)
            }
            renderType(context, mgr, Widget5x2DreamProgressProvider::class.java, R.layout.widget_5x2_dream, R.id.widgetRoot5x2Dream, 570) { rv ->
                bind5x2Dream(context, rv, prices, portfolio)
            }
        } catch (e: Exception) {
            android.util.Log.e("SovereignWidget", "updateAll gagal", e)
        }
    }

    /** Update satu jenis widget saja — dipanggil dari onUpdate() provider masing-masing agar lebih efisien */
    fun updateSingleType(context: Context, providerClass: Class<*>) {
        try {
            val mgr = AppWidgetManager.getInstance(context)
            val prices = Store.loadPrices(context)
            val portfolio = Store.loadPortfolio(context)
            val snap = PortfolioCalculator.calculate(prices, portfolio)

            when (providerClass) {
                Widget2x2Provider::class.java ->
                    renderType(context, mgr, providerClass, R.layout.widget_2x2, R.id.widgetRoot2x2, 200) { rv -> bind2x2(context, rv, snap) }
                Widget3x2Provider::class.java ->
                    renderType(context, mgr, providerClass, R.layout.widget_3x2, R.id.widgetRoot3x2, 300) { rv -> bind3x2(context, rv, prices) }
                Widget5x2Provider::class.java ->
                    renderType(context, mgr, providerClass, R.layout.widget_5x2, R.id.widgetRoot5x2, 500) { rv -> bind5x2(context, rv, snap, prices) }
                Widget5x3Provider::class.java ->
                    renderType(context, mgr, providerClass, R.layout.widget_5x3, R.id.widgetRoot5x3, 530) { rv -> bind5x3(context, rv, snap, prices) }
                Widget5x3DividendProvider::class.java ->
                    renderType(context, mgr, providerClass, R.layout.widget_5x3_dividend, R.id.widgetRoot5x3Dividend, 560) { rv -> bind5x3Dividend(context, rv, prices) }
                Widget5x2DreamProgressProvider::class.java ->
                    renderType(context, mgr, providerClass, R.layout.widget_5x2_dream, R.id.widgetRoot5x2Dream, 570) { rv -> bind5x2Dream(context, rv, prices, portfolio) }
            }
        } catch (e: Exception) {
            android.util.Log.e("SovereignWidget", "updateSingleType gagal untuk $providerClass", e)
        }
    }

    private fun renderType(
        context: Context,
        mgr: AppWidgetManager,
        providerClass: Class<*>,
        layoutRes: Int,
        rootViewId: Int,
        baseRequestCode: Int,
        bind: (RemoteViews) -> Unit
    ) {
        val ids = try {
            mgr.getAppWidgetIds(ComponentName(context, providerClass))
        } catch (e: Exception) {
            android.util.Log.e("SovereignWidget", "getAppWidgetIds gagal untuk $providerClass", e)
            return
        }
        if (ids.isEmpty()) return

        for (id in ids) {
            try {
                val rv = RemoteViews(context.packageName, layoutRes)
                bind(rv)
                rv.setOnClickPendingIntent(rootViewId, openAppIntent(context, baseRequestCode + id))
                mgr.updateAppWidget(id, rv)
            } catch (e: Exception) {
                android.util.Log.e("SovereignWidget", "Render gagal untuk widget id=$id ($providerClass)", e)
            }
        }
    }

    // ───────────────────────────────────────────────
    // BINDING PER UKURAN WIDGET
    // ───────────────────────────────────────────────

    private fun bind2x2(context: Context, rv: RemoteViews, snap: PortfolioCalculator.Snapshot) {
        rv.setTextViewText(R.id.tvNetWorth, Formatters.fRpCompact(snap.netWorth))
        rv.setTextViewText(R.id.tvSistemPct, "${String.format("%.0f", snap.sistem.pct)}%")
        rv.setInt(R.id.dotStatus2x2, "setColorFilter", dotColorForPct(snap.sistem.pct))
        rv.setTextViewText(R.id.tvLastUpdate2x2, timeNow())
        rv.setOnClickPendingIntent(
            R.id.btnRefresh2x2, refreshIntent(context, Widget2x2Provider::class.java, 201)
        )
    }

    private fun bind3x2(context: Context, rv: RemoteViews, prices: PriceSnapshot) {
        rv.setTextViewText(R.id.tvLastUpdate3x2, timeNow())

        rv.setTextViewText(R.id.tvBtcPrice, prices.btcUsd?.let { Formatters.fUsd(it, 0) } ?: "$--")
        rv.setTextViewText(R.id.tvBtcChg, Formatters.fPct(prices.btcChg))
        rv.setImageViewResource(R.id.ivBtcTrend, trendIcon(prices.btcChg))
        rv.setTextColor(R.id.tvBtcChg, trendColor(prices.btcChg))

        rv.setTextViewText(R.id.tvBbriPrice, prices.bbriPrice?.let { Formatters.fRpFull(it) } ?: "Rp --")
        rv.setTextViewText(R.id.tvBbriChg, Formatters.fPct(prices.bbriChg))
        rv.setImageViewResource(R.id.ivBbriTrend, trendIcon(prices.bbriChg))
        rv.setTextColor(R.id.tvBbriChg, trendColor(prices.bbriChg))

        rv.setTextViewText(R.id.tvBmriPrice, prices.bmriPrice?.let { Formatters.fRpFull(it) } ?: "Rp --")
        rv.setTextViewText(R.id.tvBmriChg, Formatters.fPct(prices.bmriChg))
        rv.setImageViewResource(R.id.ivBmriTrend, trendIcon(prices.bmriChg))
        rv.setTextColor(R.id.tvBmriChg, trendColor(prices.bmriChg))

        rv.setOnClickPendingIntent(
            R.id.btnRefresh3x2, refreshIntent(context, Widget3x2Provider::class.java, 301)
        )
    }

    private fun bind5x2(context: Context, rv: RemoteViews, snap: PortfolioCalculator.Snapshot, prices: PriceSnapshot) {
        rv.setTextViewText(R.id.tvLastUpdate5x2, "Update ${timeNow()}")
        rv.setTextViewText(R.id.tvNetWorth5x2, Formatters.fRpCompact(snap.netWorth))
        rv.setTextViewText(R.id.tvSistemPct5x2, "Sistem ${String.format("%.0f", snap.sistem.pct)}%")
        rv.setInt(R.id.dotStatus5x2, "setColorFilter", dotColorForPct(snap.sistem.pct))

        rv.setTextViewText(R.id.tvBtcPrice5x2, prices.btcUsd?.let { Formatters.fUsd(it, 0) } ?: "$--")
        rv.setTextViewText(R.id.tvGoldPrice5x2, prices.goldUsd?.let { Formatters.fUsd(it, 0) } ?: "$--")
        rv.setTextViewText(R.id.tvBbriPrice5x2, prices.bbriPrice?.let { Formatters.fRpFull(it) } ?: "--")
        rv.setTextViewText(R.id.tvBmriPrice5x2, prices.bmriPrice?.let { Formatters.fRpFull(it) } ?: "--")

        rv.setOnClickPendingIntent(
            R.id.btnRefresh5x2, refreshIntent(context, Widget5x2Provider::class.java, 501)
        )
    }

    private fun bind5x3(context: Context, rv: RemoteViews, snap: PortfolioCalculator.Snapshot, prices: PriceSnapshot) {
        rv.setTextViewText(R.id.tvLastUpdate5x3, "Update ${timeNow()}")
        rv.setTextViewText(R.id.tvNetWorth5x3, Formatters.fRpCompact(snap.netWorth))
        rv.setTextViewText(R.id.tvSistemPct5x3, "${String.format("%.1f", snap.sistem.pct)}%")
        rv.setInt(R.id.dotStatus5x3, "setColorFilter", dotColorForPct(snap.sistem.pct))

        rv.setTextViewText(R.id.tvBtcPrice5x3, prices.btcUsd?.let { Formatters.fUsd(it, 0) } ?: "$--")
        rv.setTextViewText(R.id.tvBtcChg5x3, Formatters.fPct(prices.btcChg))
        rv.setImageViewResource(R.id.ivBtcTrend5x3, trendIcon(prices.btcChg))
        rv.setTextColor(R.id.tvBtcChg5x3, trendColor(prices.btcChg))

        rv.setTextViewText(R.id.tvGoldPrice5x3, prices.goldUsd?.let { Formatters.fUsd(it, 0) } ?: "$--")
        rv.setTextViewText(R.id.tvGoldChg5x3, Formatters.fPct(prices.goldChg))
        rv.setImageViewResource(R.id.ivGoldTrend5x3, trendIcon(prices.goldChg))
        rv.setTextColor(R.id.tvGoldChg5x3, trendColor(prices.goldChg))

        rv.setTextViewText(R.id.tvBbriPrice5x3, prices.bbriPrice?.let { Formatters.fRpFull(it) } ?: "Rp --")
        rv.setTextViewText(R.id.tvBbriChg5x3, Formatters.fPct(prices.bbriChg))
        rv.setImageViewResource(R.id.ivBbriTrend5x3, trendIcon(prices.bbriChg))
        rv.setTextColor(R.id.tvBbriChg5x3, trendColor(prices.bbriChg))

        rv.setTextViewText(R.id.tvBmriPrice5x3, prices.bmriPrice?.let { Formatters.fRpFull(it) } ?: "Rp --")
        rv.setTextViewText(R.id.tvBmriChg5x3, Formatters.fPct(prices.bmriChg))
        rv.setImageViewResource(R.id.ivBmriTrend5x3, trendIcon(prices.bmriChg))
        rv.setTextColor(R.id.tvBmriChg5x3, trendColor(prices.bmriChg))

        rv.setTextViewText(
            R.id.tvBtcProgress5x3,
            "${String.format("%.4f", snap.btcOwned)} / ${snap.btcTarget} BTC"
        )
        rv.setTextViewText(R.id.tvDividenTotal5x3, Formatters.fRpCompact(snap.dividenTotalThn))

        rv.setOnClickPendingIntent(
            R.id.btnRefresh5x3, refreshIntent(context, Widget5x3Provider::class.java, 531)
        )
    }

    private fun bind5x3Dividend(context: Context, rv: RemoteViews, prices: PriceSnapshot) {
        val portfolio = Store.loadPortfolio(context)
        rv.setTextViewText(R.id.tvLastUpdate5x3Div, timeNow())

        // Slow Living Tracker
        val totalDivTahunan = (portfolio.bbriDps * portfolio.bbriLot * 100.0) +
            (portfolio.bmriDps * portfolio.bmriLot * 100.0)
        val tracker = PortfolioCalculator.calcSlowLivingTracker(portfolio, totalDivTahunan)

        rv.setTextViewText(R.id.tvDaysPaid5x3Div, "${tracker.daysPaid}/30 hari")
        rv.setProgressBar(R.id.progressSlowLiving, 30, tracker.daysPaid, false)
        rv.setTextViewText(
            R.id.tvSlowLivingNote5x3Div,
            "Div harian ${Formatters.fRpCompact(tracker.divHarian)} | Target ${Formatters.fRpCompact(tracker.targetHarian)}/hari"
        )

        // Estimasi Dividen breakdown
        val divBbriThn = portfolio.bbriDps * portfolio.bbriLot * 100.0
        val divBmriThn = portfolio.bmriDps * portfolio.bmriLot * 100.0
        val divTotalBulan = totalDivTahunan / 12.0

        rv.setTextViewText(R.id.tvDivBbri5x3Div, Formatters.fRpCompact(divBbriThn))
        rv.setTextViewText(R.id.tvDivBmri5x3Div, Formatters.fRpCompact(divBmriThn))
        rv.setTextViewText(R.id.tvDivTotalBulan5x3Div, Formatters.fRpCompact(divTotalBulan))

        // Kekurangan Lot
        val kekurangan = PortfolioCalculator.calcKekuranganLot(
            portfolio,
            prices.bbriPrice ?: 0.0,
            prices.bmriPrice ?: 0.0
        )

        when {
            kekurangan == null -> {
                rv.setTextViewText(R.id.tvKurangBbri5x3Div, "Tunggu harga live...")
                rv.setTextViewText(R.id.tvKurangBmri5x3Div, "Tunggu harga live...")
            }
            kekurangan.sudahCukup -> {
                rv.setTextViewText(R.id.tvKurangBbri5x3Div, "Sudah cukup ✓")
                rv.setTextViewText(R.id.tvKurangBmri5x3Div, "Sudah cukup ✓")
                rv.setTextColor(R.id.tvKurangBbri5x3Div, 0xFFF5F5F0.toInt())
                rv.setTextColor(R.id.tvKurangBmri5x3Div, 0xFFF5F5F0.toInt())
            }
            else -> {
                rv.setTextViewText(
                    R.id.tvKurangBbri5x3Div,
                    "+${kekurangan.bbriTambahLot} lot = ${Formatters.fRpCompact(kekurangan.danaBbri)}"
                )
                rv.setTextViewText(
                    R.id.tvKurangBmri5x3Div,
                    "+${kekurangan.bmriTambahLot} lot = ${Formatters.fRpCompact(kekurangan.danaBmri)}"
                )
                rv.setTextColor(R.id.tvKurangBbri5x3Div, 0xFFF5F5F0.toInt())
                rv.setTextColor(R.id.tvKurangBmri5x3Div, 0xFFF5F5F0.toInt())
            }
        }

        rv.setOnClickPendingIntent(
            R.id.btnRefresh5x3Div, refreshIntent(context, Widget5x3DividendProvider::class.java, 561)
        )
    }

    /**
     * Bind widget "Progress Achieve Dream" (5x2, NEW) — 4 progress bar:
     * Dividen Slow Living, BTC, Emas, VTI/SPX500. Sengaja TIDAK menampilkan
     * Net Worth (permintaan user, dianggap kurang relevan untuk dipajang).
     */
    private fun bind5x2Dream(context: Context, rv: RemoteViews, prices: PriceSnapshot, portfolio: PortfolioConfig) {
        rv.setTextViewText(R.id.tvLastUpdate5x2Dream, timeNow())

        val dream = PortfolioCalculator.calcDreamProgress(prices, portfolio)

        rv.setProgressBar(R.id.pbDreamDividen, 100, dream.dividen.pct.toInt(), false)
        rv.setTextViewText(R.id.tvDreamDividenDetail, dream.dividen.detail)

        rv.setProgressBar(R.id.pbDreamBtc, 100, dream.btc.pct.toInt(), false)
        rv.setTextViewText(R.id.tvDreamBtcDetail, dream.btc.detail)

        rv.setProgressBar(R.id.pbDreamEmas, 100, dream.emas.pct.toInt(), false)
        rv.setTextViewText(R.id.tvDreamEmasDetail, dream.emas.detail)

        rv.setProgressBar(R.id.pbDreamVtiSpx, 100, dream.vtiSpx.pct.toInt(), false)
        rv.setTextViewText(R.id.tvDreamVtiSpxDetail, dream.vtiSpx.detail)

        rv.setOnClickPendingIntent(
            R.id.btnRefresh5x2Dream, refreshIntent(context, Widget5x2DreamProgressProvider::class.java, 571)
        )
    }
}
