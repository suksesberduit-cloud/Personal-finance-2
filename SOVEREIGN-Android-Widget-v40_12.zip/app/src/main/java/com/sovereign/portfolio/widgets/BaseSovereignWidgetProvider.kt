package com.sovereign.portfolio.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.sovereign.portfolio.ACTION_REFRESH
import com.sovereign.portfolio.NetworkFetcher
import com.sovereign.portfolio.Store
import com.sovereign.portfolio.WidgetUpdater
import com.sovereign.portfolio.WorkScheduler
import java.util.concurrent.Executors

/**
 * Base provider — semua 4 ukuran widget extend class ini supaya logic
 * onUpdate/onEnabled/onReceive seragam tanpa duplikasi.
 *
 * CATATAN PENTING soal robustness: setiap callback di sini DIBUNGKUS try-catch
 * defensif. AppWidgetProvider/RemoteViews sangat tidak toleran terhadap
 * exception yang lolos — satu exception yang tidak tertangkap di onUpdate()
 * akan membuat sistem menampilkan "Tidak dapat memuat widget" secara permanen
 * untuk instance widget itu, bukan cuma sekali gagal. Maka SEMUA path kode di
 * sini, termasuk yang berjalan di background thread/Handler.post, wajib
 * punya try-catch sendiri — tidak boleh mengandalkan try-catch di level lain
 * karena exception yang dilempar di dalam Runnable terpisah (mis. dari
 * mainHandler.post{}) TIDAK akan tertangkap oleh try-catch di luar lambda itu.
 */
abstract class BaseSovereignWidgetProvider : AppWidgetProvider() {

    companion object {
        private const val TAG = "SovereignWidget"
        private val bgExecutor = Executors.newSingleThreadExecutor()
        private val mainHandler = Handler(Looper.getMainLooper())
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        safeRun("onUpdate") {
            // Render dulu dengan apapun yang ada di cache (instan, supaya widget tidak blank sama sekali)
            WidgetUpdater.updateSingleType(context, this.javaClass)
        }
        // Fetch fresh data di background dengan budget waktu terbatas — dibungkus
        // try-catch sendiri di dalam fungsinya, tidak boleh sampai melempar ke sini
        fetchAndRenderWithTimeBudget(context)
    }

    override fun onEnabled(context: Context) {
        safeRun("onEnabled") {
            WorkScheduler.schedulePeriodic(context)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        // PENTING: panggil super.onReceive() dalam try-catch juga, karena ini
        // yang memanggil onUpdate()/onEnabled() di internal AppWidgetProvider.
        // Kalau salah satu dari situ throw, exception akan menjalar sampai ke
        // sini dan widget host akan menandai widget sebagai gagal permanen.
        try {
            super.onReceive(context, intent)
        } catch (e: Exception) {
            Log.e(TAG, "Exception in super.onReceive", e)
        }

        if (intent.action == ACTION_REFRESH) {
            safeRun("onReceive-refresh") {
                WidgetUpdater.updateSingleType(context, this.javaClass)
            }
            fetchAndRenderWithTimeBudget(context)
        }
    }

    /** Helper untuk menjalankan blok kode dengan try-catch konsisten + logging,
     * supaya tidak ada satupun jalur eksekusi yang bisa melempar exception
     * tak tertangani ke pemanggil (AppWidgetManager/sistem). */
    private inline fun safeRun(label: String, block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            Log.e(TAG, "Exception in $label", e)
        }
    }

    /**
     * Minta perpanjangan waktu eksekusi dari sistem (goAsync), fetch data di
     * thread background dengan timeout ketat (maksimal 8 detik supaya aman
     * di bawah batas sistem ~10s untuk BroadcastReceiver), simpan ke cache,
     * lalu render ulang semua widget jenis ini di main thread sebelum
     * melepas pending result. Kalau fetch gagal/timeout, cache lama tetap
     * dipakai — widget tidak pernah crash atau blank total.
     *
     * SETIAP layer (background thread, callback ke main thread) punya
     * try-catch sendiri yang independen, karena exception yang dilempar di
     * dalam lambda terpisah (Runnable untuk Executor maupun Handler) tidak
     * akan tertangkap oleh try-catch di luar lambda tersebut.
     */
    private fun fetchAndRenderWithTimeBudget(context: Context) {
        val pending = try {
            goAsync()
        } catch (e: Exception) {
            // goAsync() bisa gagal kalau dipanggil di luar window onReceive yang valid
            // (misal sistem sudah menganggap receiver ini selesai). Kalau gagal,
            // tetap coba render langsung dari cache yang ada tanpa fetch baru,
            // supaya widget tidak pernah benar-benar gagal total.
            Log.e(TAG, "goAsync() gagal dipanggil", e)
            safeRun("fallback-render-no-async") {
                WidgetUpdater.updateSingleType(context, this.javaClass)
            }
            return
        }

        bgExecutor.execute {
            try {
                try {
                    val fresh = NetworkFetcher.fetchAllWithTimeout(8000)
                    val cached = Store.loadPrices(context)
                    val merged = fresh.mergeWithFallback(cached)
                    Store.savePrices(context, merged)
                } catch (e: Exception) {
                    Log.e(TAG, "Fetch gagal, cache lama tetap dipakai", e)
                }

                mainHandler.post {
                    safeRun("render-after-fetch") {
                        WidgetUpdater.updateSingleType(context, this.javaClass)
                    }
                    finishPendingResultSafely(pending)
                }
            } catch (e: Throwable) {
                // Lapisan terluar — jaring pengaman terakhir. Kalau entah bagaimana
                // ada exception lolos sampai sini, tetap pastikan goAsync() dilepas
                // supaya sistem tidak menunggu/menganggap widget macet.
                Log.e(TAG, "Unexpected error di background fetch", e)
                finishPendingResultSafely(pending)
            }
        }
    }

    private fun finishPendingResultSafely(pending: android.content.BroadcastReceiver.PendingResult) {
        try {
            pending.finish()
        } catch (e: IllegalStateException) {
            // Diketahui terjadi di beberapa device OEM ("Broadcast already finished").
            // Lihat: https://issuetracker.google.com/issues/257513022 — aman diabaikan.
            Log.e(TAG, "pending.finish() gagal (dikenal terjadi di beberapa OEM)", e)
        }
    }
}
