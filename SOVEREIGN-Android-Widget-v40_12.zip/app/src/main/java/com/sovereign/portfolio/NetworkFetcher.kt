package com.sovereign.portfolio

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * Fetcher data harga — logic mirror dari fetchBtc()/fetchGold()/fetchSahamID() di index.html,
 * tapi disederhanakan karena app native TIDAK terkena CORS, jadi tidak perlu proxy berlapis
 * seperti di PWA (allorigins/corsproxy/thingproxy). Cukup hit API langsung dengan timeout.
 */
object NetworkFetcher {

    private fun httpGet(urlStr: String, timeoutMs: Int = 5000): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlStr)
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.setRequestProperty("User-Agent", "SOVEREIGN-Widget/1.0 (Android)")
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    /** BTC — Binance Vision (sama seperti PWA), fallback CoinGecko */
    fun fetchBtc(): Pair<Double, Double>? {
        try {
            val priceRaw = httpGet("https://data-api.binance.vision/api/v3/ticker/price?symbol=BTCUSDT", 3000)
            val chgRaw = httpGet("https://data-api.binance.vision/api/v3/ticker/24hr?symbol=BTCUSDT", 3000)
            if (priceRaw != null && chgRaw != null) {
                val price = JSONObject(priceRaw).getDouble("price")
                val chg = JSONObject(chgRaw).getDouble("priceChangePercent")
                return Pair(price, chg)
            }
        } catch (e: Exception) { /* fallthrough */ }

        try {
            val raw = httpGet(
                "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true",
                6000
            )
            if (raw != null) {
                val d = JSONObject(raw).getJSONObject("bitcoin")
                return Pair(d.getDouble("usd"), d.optDouble("usd_24h_change", 0.0))
            }
        } catch (e: Exception) { /* give up */ }

        return null
    }

    /** GOLD — gold-api.com (sama seperti PWA source 1), fallback Yahoo chart langsung (tanpa proxy) */
    fun fetchGold(): Pair<Double, Double>? {
        try {
            val raw = httpGet("https://gold-api.com/price/XAU", 4000)
            if (raw != null) {
                val d = JSONObject(raw)
                val price = d.getDouble("price")
                val prev = d.optDouble("prev_close_price", 0.0)
                val chg = if (prev > 0) ((price - prev) / prev) * 100 else 0.0
                return Pair(price, chg)
            }
        } catch (e: Exception) { /* fallthrough */ }

        try {
            val raw = httpGet(
                "https://query1.finance.yahoo.com/v8/finance/chart/GC%3DF?interval=1d&range=2d",
                6000
            )
            if (raw != null) {
                val result = parseYahooChart(raw)
                if (result != null) return result
            }
        } catch (e: Exception) { /* give up */ }

        return null
    }

    /** Saham IDN — Yahoo quote langsung (native, no proxy), fallback chart */
    fun fetchTicker(ticker: String): Pair<Double, Double>? {
        try {
            val raw = httpGet(
                "https://query1.finance.yahoo.com/v7/finance/quote?symbols=$ticker&fields=regularMarketPrice,regularMarketChangePercent",
                5000
            )
            if (raw != null) {
                val d = JSONObject(raw)
                val q = d.getJSONObject("quoteResponse").getJSONArray("result")
                if (q.length() > 0) {
                    val obj = q.getJSONObject(0)
                    if (obj.has("regularMarketPrice")) {
                        return Pair(
                            obj.getDouble("regularMarketPrice"),
                            obj.optDouble("regularMarketChangePercent", 0.0)
                        )
                    }
                }
            }
        } catch (e: Exception) { /* fallthrough */ }

        try {
            val raw = httpGet(
                "https://query1.finance.yahoo.com/v8/finance/chart/$ticker?interval=1d&range=2d",
                6000
            )
            if (raw != null) {
                val result = parseYahooChart(raw)
                if (result != null) return result
            }
        } catch (e: Exception) { /* give up */ }

        return null
    }

    private fun parseYahooChart(raw: String): Pair<Double, Double>? {
        return try {
            val d = JSONObject(raw)
            val result = d.getJSONObject("chart").getJSONArray("result").getJSONObject(0)
            val closeArr = result.getJSONObject("indicators")
                .getJSONArray("quote").getJSONObject(0).getJSONArray("close")
            val closes = mutableListOf<Double>()
            for (i in 0 until closeArr.length()) {
                if (!closeArr.isNull(i)) closes.add(closeArr.getDouble(i))
            }
            if (closes.isEmpty()) return null
            val cur = closes.last()
            val prev = if (closes.size >= 2) closes[closes.size - 2] else cur
            Pair(cur, if (prev != 0.0) ((cur - prev) / prev) * 100 else 0.0)
        } catch (e: Exception) {
            null
        }
    }

    /** Kurs USD/IDR — Yahoo direct */
    fun fetchKurs(): Double? {
        try {
            val encodedSymbol = java.net.URLEncoder.encode("USDIDR=X", "UTF-8")
            val raw = httpGet(
                "https://query1.finance.yahoo.com/v7/finance/quote?symbols=$encodedSymbol&fields=regularMarketPrice",
                5000
            )
            if (raw != null) {
                val d = JSONObject(raw)
                val q = d.getJSONObject("quoteResponse").getJSONArray("result")
                if (q.length() > 0) {
                    return q.getJSONObject(0).optDouble("regularMarketPrice")
                }
            }
        } catch (e: Exception) { /* ignore, keep default */ }
        return null
    }

    /**
     * Fetch semua data sekaligus secara sequential (blocking — dipanggil dari
     * background thread/Worker biasa yang TIDAK punya batas waktu ketat).
     * Dipakai oleh PriceUpdateWorker untuk refresh periodik 15 menit.
     */
    fun fetchAll(): PriceSnapshot {
        val snapshot = PriceSnapshot(savedAt = System.currentTimeMillis())

        fetchBtc()?.let {
            snapshot.btcUsd = it.first
            snapshot.btcChg = it.second
        }
        fetchGold()?.let {
            snapshot.goldUsd = it.first
            snapshot.goldChg = it.second
        }
        fetchTicker("BBRI.JK")?.let {
            snapshot.bbriPrice = it.first
            snapshot.bbriChg = it.second
        }
        fetchTicker("BMRI.JK")?.let {
            snapshot.bmriPrice = it.first
            snapshot.bmriChg = it.second
        }
        fetchKurs()?.let {
            snapshot.kursUsd = it
        }

        return snapshot
    }

    /**
     * Versi PARALEL dengan hard deadline keseluruhan — dipakai khusus dari
     * BroadcastReceiver.goAsync() yang punya batas waktu ketat dari sistem
     * (umumnya ~10 detik sebelum dianggap macet/ANR). Semua 5 fetch
     * dijalankan BERSAMAAN di thread pool terpisah, dan keseluruhan proses
     * dipotong paksa di totalTimeoutMs walau ada request yang belum selesai
     * — request yang belum selesai itu hasilnya diabaikan (null), tidak
     * membuat fungsi ini ikut menunggu lebih lama.
     */
    fun fetchAllWithTimeout(totalTimeoutMs: Long): PriceSnapshot {
        val snapshot = PriceSnapshot(savedAt = System.currentTimeMillis())
        val pool = java.util.concurrent.Executors.newFixedThreadPool(5)

        try {
            val btcFuture = pool.submit<Pair<Double, Double>?> { fetchBtc() }
            val goldFuture = pool.submit<Pair<Double, Double>?> { fetchGold() }
            val bbriFuture = pool.submit<Pair<Double, Double>?> { fetchTicker("BBRI.JK") }
            val bmriFuture = pool.submit<Pair<Double, Double>?> { fetchTicker("BMRI.JK") }
            val kursFuture = pool.submit<Double?> { fetchKurs() }

            val deadline = System.currentTimeMillis() + totalTimeoutMs

            fun <T> safeGet(future: java.util.concurrent.Future<T>): T? {
                val remaining = deadline - System.currentTimeMillis()
                if (remaining <= 0) return null
                return try {
                    future.get(remaining, TimeUnit.MILLISECONDS)
                } catch (e: Exception) {
                    null
                }
            }

            safeGet(btcFuture)?.let {
                snapshot.btcUsd = it.first
                snapshot.btcChg = it.second
            }
            safeGet(goldFuture)?.let {
                snapshot.goldUsd = it.first
                snapshot.goldChg = it.second
            }
            safeGet(bbriFuture)?.let {
                snapshot.bbriPrice = it.first
                snapshot.bbriChg = it.second
            }
            safeGet(bmriFuture)?.let {
                snapshot.bmriPrice = it.first
                snapshot.bmriChg = it.second
            }
            safeGet(kursFuture)?.let {
                snapshot.kursUsd = it
            }
        } finally {
            pool.shutdownNow()
        }

        return snapshot
    }
}
