package com.sovereign.portfolio.widgets

/** Widget ukuran 3x2 — compact: BTC + BBRI + BMRI live price & trend */
class Widget3x2Provider : BaseSovereignWidgetProvider()
