package com.sovereign.portfolio.widgets

/** Widget ukuran 5x2 — dashboard ringkas: net worth + 4 mini metric (BTC/Gold/BBRI/BMRI) */
class Widget5x2Provider : BaseSovereignWidgetProvider()
