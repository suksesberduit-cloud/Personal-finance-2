package com.sovereign.portfolio.widgets

/** Widget ukuran 5x3 (varian kedua) — fokus Slow Living Tracker, Estimasi Dividen, dan Kekurangan Lot */
class Widget5x3DividendProvider : BaseSovereignWidgetProvider()
