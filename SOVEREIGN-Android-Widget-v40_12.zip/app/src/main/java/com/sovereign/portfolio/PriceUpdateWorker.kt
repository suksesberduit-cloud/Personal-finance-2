package com.sovereign.portfolio

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Worker yang dijalankan WorkManager setiap 15 menit (battery-friendly, sesuai
 * batas minimum periodic work Android — anything below 15 menit akan di-clamp
 * sistem ke 15 menit juga, jadi ini sudah optimal).
 */
class PriceUpdateWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val snapshot = withContext(Dispatchers.IO) {
                NetworkFetcher.fetchAll()
            }
            val cached = Store.loadPrices(applicationContext)
            val merged = snapshot.mergeWithFallback(cached)
            Store.savePrices(applicationContext, merged)
            WidgetUpdater.updateAll(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "sovereign_price_update_worker"
        const val WORK_NAME_ONE_TIME = "sovereign_price_update_onetime"
    }
}
