package com.sovereign.portfolio.widgets

/** Widget ukuran 5x2 (varian baru) — progress menuju 4 tujuan: Dividen Slow Living, BTC, Emas, VTI/SPX500.
 * Sengaja TIDAK menampilkan Net Worth (permintaan user). Widget5x2Provider lama tetap dipertahankan
 * sebagai pilihan terpisah, bukan diganti. */
class Widget5x2DreamProgressProvider : BaseSovereignWidgetProvider()
