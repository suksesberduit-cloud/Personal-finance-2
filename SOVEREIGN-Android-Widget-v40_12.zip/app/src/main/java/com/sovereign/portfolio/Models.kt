package com.sovereign.portfolio

import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

/**
 * Snapshot harga live — mirror dari objek `prices` di index.html PWA SOVEREIGN.
 */
data class PriceSnapshot(
    var btcUsd: Double? = null,
    var btcChg: Double? = null,
    var goldUsd: Double? = null,
    var goldChg: Double? = null,
    var bbriPrice: Double? = null,
    var bbriChg: Double? = null,
    var bmriPrice: Double? = null,
    var bmriChg: Double? = null,
    var kursUsd: Double = 16400.0,
    var savedAt: Long = 0L
) {
    fun toJson(): String {
        val o = JSONObject()
        o.put("btcUsd", btcUsd ?: JSONObject.NULL)
        o.put("btcChg", btcChg ?: JSONObject.NULL)
        o.put("goldUsd", goldUsd ?: JSONObject.NULL)
        o.put("goldChg", goldChg ?: JSONObject.NULL)
        o.put("bbriPrice", bbriPrice ?: JSONObject.NULL)
        o.put("bbriChg", bbriChg ?: JSONObject.NULL)
        o.put("bmriPrice", bmriPrice ?: JSONObject.NULL)
        o.put("bmriChg", bmriChg ?: JSONObject.NULL)
        o.put("kursUsd", kursUsd)
        o.put("savedAt", savedAt)
        return o.toString()
    }

    /**
     * Gabungkan snapshot ini (hasil fetch terbaru, mungkin sebagian null kalau
     * timeout) dengan snapshot cache lama — field yang null di sini akan
     * diisi dari cache, supaya widget tidak pernah menampilkan "--" untuk
     * data yang sebenarnya pernah berhasil di-fetch sebelumnya.
     */
    fun mergeWithFallback(cached: PriceSnapshot): PriceSnapshot {
        return PriceSnapshot(
            btcUsd = this.btcUsd ?: cached.btcUsd,
            btcChg = this.btcChg ?: cached.btcChg,
            goldUsd = this.goldUsd ?: cached.goldUsd,
            goldChg = this.goldChg ?: cached.goldChg,
            bbriPrice = this.bbriPrice ?: cached.bbriPrice,
            bbriChg = this.bbriChg ?: cached.bbriChg,
            bmriPrice = this.bmriPrice ?: cached.bmriPrice,
            bmriChg = this.bmriChg ?: cached.bmriChg,
            kursUsd = if (this.kursUsd > 0) this.kursUsd else cached.kursUsd,
            savedAt = System.currentTimeMillis()
        )
    }

    companion object {
        fun fromJson(str: String?): PriceSnapshot {
            if (str.isNullOrEmpty()) return PriceSnapshot()
            return try {
                val o = JSONObject(str)
                PriceSnapshot(
                    btcUsd = o.optDoubleOrNull("btcUsd"),
                    btcChg = o.optDoubleOrNull("btcChg"),
                    goldUsd = o.optDoubleOrNull("goldUsd"),
                    goldChg = o.optDoubleOrNull("goldChg"),
                    bbriPrice = o.optDoubleOrNull("bbriPrice"),
                    bbriChg = o.optDoubleOrNull("bbriChg"),
                    bmriPrice = o.optDoubleOrNull("bmriPrice"),
                    bmriChg = o.optDoubleOrNull("bmriChg"),
                    kursUsd = o.optDouble("kursUsd", 16400.0),
                    savedAt = o.optLong("savedAt", 0L)
                )
            } catch (e: Exception) {
                PriceSnapshot()
            }
        }

        private fun JSONObject.optDoubleOrNull(key: String): Double? {
            return if (this.isNull(key) || !this.has(key)) null else this.optDouble(key)
        }
    }
}

/**
 * Mirror dari DEFAULT_PORTFOLIO di index.html — disinkronkan manual oleh user
 * (lihat SettingsActivity / nilai default sesuai handover SOVEREIGN v40).
 */
data class PortfolioConfig(
    var btcOwned: Double = 0.0056,
    var emasGram: Double = 0.0,
    var bbriLot: Int = 516,
    var bbriAvg: Double = 4200.0,
    var bmriLot: Int = 309,
    var bmriAvg: Double = 5800.0,
    var vtiUsd: Double = 0.0,
    var vtiCostUsd: Double = 0.0,
    var spx500Usd: Double = 0.0,
    var spx500CostUsd: Double = 0.0,
    var slowLivingHarian: Double = 150000.0,
    var bbriDps: Double = 346.00,
    var bmriDps: Double = 476.95,
    var btcTargetOwned: Double = 0.2,
    var emasTargetGram: Double = 30.0,
    var totalInvestRencana: Double = 0.0
)

object Formatters {
    private val idLocale = Locale("in", "ID")

    /** Format Rupiah ringkas: Rp 1.2M, Rp 850Jt, Rp 12Jt dst — supaya muat di widget kecil */
    fun fRpCompact(value: Double): String {
        val abs = Math.abs(value)
        return when {
            abs >= 1_000_000_000 -> "Rp${formatNum(value / 1_000_000_000, 2)}M"
            abs >= 1_000_000 -> "Rp${formatNum(value / 1_000_000, 1)}Jt"
            abs >= 1_000 -> "Rp${formatNum(value / 1_000, 0)}rb"
            else -> "Rp${value.toInt()}"
        }
    }

    /** Format Rupiah penuh dengan separator titik */
    fun fRpFull(value: Double): String {
        val nf = NumberFormat.getNumberInstance(idLocale)
        nf.maximumFractionDigits = 0
        return "Rp${nf.format(value)}"
    }

    fun fUsd(value: Double, decimals: Int = 0): String {
        val nf = NumberFormat.getNumberInstance(Locale.US)
        nf.maximumFractionDigits = decimals
        nf.minimumFractionDigits = decimals
        return "$${nf.format(value)}"
    }

    fun fPct(value: Double?): String {
        if (value == null) return "--%"
        val sign = if (value >= 0) "+" else ""
        return "$sign${formatNum(value, 2)}%"
    }

    private fun formatNum(value: Double, decimals: Int): String {
        val nf = NumberFormat.getNumberInstance(idLocale)
        nf.maximumFractionDigits = decimals
        nf.minimumFractionDigits = decimals
        return nf.format(value)
    }
}
