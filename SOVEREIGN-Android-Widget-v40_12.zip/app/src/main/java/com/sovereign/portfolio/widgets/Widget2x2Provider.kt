package com.sovereign.portfolio.widgets

/** Widget ukuran 2x2 — minimal: net worth + status sistem slow living */
class Widget2x2Provider : BaseSovereignWidgetProvider()
