# Add project specific ProGuard rules here.
-keep class com.sovereign.portfolio.** { *; }
-keepclassmembers class com.sovereign.portfolio.MainActivity$SovereignBridge {
   public *;
}
