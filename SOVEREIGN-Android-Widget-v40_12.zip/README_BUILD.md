# SOVEREIGN — Android Wrapper + Home Screen Widgets

Project Android native (Kotlin) yang membungkus PWA SOVEREIGN v40 (tidak ada satu baris pun
diubah dari `index.html` aslinya) ke dalam app yang bisa di-install, plus 4 ukuran
**App Widget** untuk homescreen Android: **5x2, 5x3, 3x2, 2x2**.

## ✨ v40.5 — Penyesuaian warna spesifik per elemen (Slow Living & Dividen)

Lanjutan dari v40.4, tapi kali ini per elemen diberi warna semantik
masing-masing (bukan putih cerah seragam):
- **"Div harian -- | Target --/hari"** → kuning emas (`#C9A84C`, gold yang
  sama dengan brand color SOVEREIGN)
- **Label "BBRI/thn" dan "BMRI/thn"** → putih cerah (`#F5F5F0`)
- **"KURANG LOT UNTUK CAPAI TARGET"** → merah (`#EF4444`, sama dengan
  `sv_red`) untuk menonjolkan urgensi gap target
Hanya perubahan warna di `widget_5x3_dividend.xml`, tidak ada perubahan
logic/Kotlin.

## ✨ v40.4 — Perbaikan kontras teks widget Slow Living & Dividen

4 label di widget `Widget5x3DividendProvider` yang sebelumnya abu-abu redup
(`#8A8A85`, sulit dibaca) diubah jadi putih cerah (`#F5F5F0`) supaya kontras
lebih jelas: "HARI TERBAYAR DIVIDEN", "Div harian -- | Target --/hari",
"TOTAL/bln", dan "KURANG LOT UNTUK CAPAI TARGET". Hanya perubahan warna di
layout XML, tidak ada perubahan logic/Kotlin.

## ✨ v40.3 — Widget kelima: Slow Living & Dividen

Ditambahkan satu widget baru ukuran 5x3 (varian kedua, terpisah dari widget
5x3 yang sudah ada), khusus fokus pada 3 komponen:

1. **Slow Living Tracker** — progress bar "hari terbayar dividen" (skala
   0-30 hari/bulan) sesuai logic persis dari tracker di dalam app.
2. **Estimasi Dividen** — breakdown BBRI/thn, BMRI/thn, dan Total/bulan.
3. **Kekurangan Lot** — simulasi berapa lot tambahan BBRI/BMRI yang
   dibutuhkan (dengan estimasi dana di harga live) supaya dividen tahunan
   mencapai target Slow Living 100%. Kalau target sudah tercapai, akan
   menampilkan "Sudah cukup ✓".

Widget lama (5x3 yang fokus BTC/Gold/BBRI/BMRI/progress BTC) **tetap ada**
tanpa perubahan — sekarang ada total 5 pilihan widget yang bisa dipasang.
Cari **"SOVEREIGN Slow Living"** di widget picker untuk widget baru ini.

## 🔧 v40.2 — Perbaikan "Tidak dapat memuat widget" (crash render)

Revisi ini memperbaiki bug yang lebih serius dari v40.1: widget gagal total
di-render ("Tidak dapat memuat widget"), bukan cuma kosong nilainya.

**Root cause**: layout widget memakai tag `<View>` polos sebagai divider garis
pemisah dan dot indikator status warna. Ternyata `RemoteViews` (komponen yang
dipakai App Widget Android) **hanya mendukung subset View tertentu** —
`LinearLayout`, `TextView`, `ImageView`, dan beberapa lainnya — sementara
`View` dasar (base class) **tidak ada dalam daftar yang didukung**. Setiap
kali sistem mencoba inflate layout yang punya tag `<View>` polos, proses itu
gagal total, dan widget host menampilkan "Tidak dapat memuat widget" secara
permanen untuk instance itu.

**Fix**: semua 11 instance `<View>` di 4 layout widget diganti jadi
`<ImageView>` (yang didukung resmi RemoteViews), dengan drawable shape yang
sama persis secara visual (garis pemisah tetap garis, dot status sekarang
pakai shape oval khusus + `setColorFilter` untuk mewarnai sesuai status
merah/kuning/hijau).

Selain itu, ditambahkan **lapisan try-catch defensif** di setiap titik kritis
(`onUpdate`, `onReceive`, `goAsync` callback, kalkulasi portfolio) — supaya
exception apapun yang mungkin terjadi di masa depan tidak akan pernah lagi
membuat widget gagal render total; minimal akan tetap menampilkan data lama
atau placeholder, sambil mencatat errornya ke Logcat untuk debugging.

## 🔧 v40.1 — Perbaikan "widget kosong"

Revisi ini memperbaiki bug di mana widget yang baru dipasang ke homescreen menampilkan
nilai kosong (`--`) tanpa pernah terisi data nyata. Root cause dan perbaikannya:

1. **Race condition** — sebelumnya widget langsung render dari cache kosong begitu
   dipasang, dan tidak ada mekanisme untuk render ulang otomatis setelah data berhasil
   di-fetch. **Fix**: widget sekarang memakai `goAsync()` untuk fetch data secara
   sinkron dengan budget waktu 8 detik begitu dipasang/diupdate, jadi widget langsung
   terisi data nyata tanpa harus menunggu siklus WorkManager 15 menit.
2. **Fetch sequential terlalu lambat** — `fetchAll()` lama melakukan ~7 HTTP request
   berurutan yang totalnya bisa melebihi batas waktu sistem untuk widget update.
   **Fix**: ditambahkan `fetchAllWithTimeout()` yang menjalankan semua fetch secara
   **paralel** dengan hard deadline keseluruhan, jadi tidak akan pernah membuat sistem
   menganggap widget "tidak merespons".
3. **Battery optimization di HP non-Pixel** (Xiaomi MIUI, Oppo ColorOS, Vivo
   FuntouchOS, Samsung) sering membekukan background work app yang baru di-install.
   **Fix**: app sekarang otomatis meminta exemption battery optimization saat pertama
   dibuka, supaya WorkManager periodic tetap konsisten jalan di background.
4. **URL encoding** — parameter ticker kurs (`USDIDR=X`) sekarang di-encode dengan
   benar untuk menghindari masalah di jaringan/proxy operator yang strict.

## 🔥 Build APK TANPA LAPTOP — pakai GitHub Actions (gratis, dari HP)

Kalau kamu tidak punya laptop, kamu bisa compile APK ini langsung dari HP lewat
**GitHub Actions** — server cloud gratis milik GitHub yang akan menjalankan Gradle build
untuk kamu. Kamu cuma butuh browser HP atau app GitHub.

### Langkah-langkah dari HP:
1. **Buat akun GitHub** (gratis) di github.com kalau belum punya, lewat browser HP.
2. **Buat repository baru** — bisa lewat app GitHub Mobile (ada di Play Store) atau
   browser. Nama bebas, misal `sovereign-android`. Set ke **Public** (supaya GitHub
   Actions gratis tanpa batas menit — private repo juga gratis tapi ada kuota bulanan).
3. **Upload 2 hal ini ke repo** (TIDAK PERLU di-extract dulu — upload file zip-nya
   langsung apa adanya, workflow CI akan extract otomatis di server GitHub):
   - File **`SOVEREIGN-Android-Widget-v40.5.zip`** ini, persis dengan nama
     tersebut, ditaruh di root repo (bukan di dalam folder apapun).
   - Folder `.github/workflows/build-apk.yml` yang ada di dalam zip ini — buka repo
     GitHub kamu → "Add file" → "Create new file", ketik nama path
     `.github/workflows/build-apk.yml` (GitHub otomatis buat foldernya), lalu copy-paste
     isi file `build-apk.yml` (ada di bagian akhir panduan ini) ke editornya, commit.
4. Setelah kedua file itu ter-commit ke branch `main`, buka tab **Actions** di repo
   GitHub kamu. Build akan otomatis jalan (atau klik "Run workflow" kalau mau trigger
   manual).
5. Tunggu sekitar 3-7 menit — GitHub akan menjalankan Gradle build di server mereka.
6. Setelah selesai (centang hijau ✅), tap judul run itu → scroll ke baris
   **Status / Total duration / Artifacts** → tap angka di kolom **Artifacts** → tap
   nama `SOVEREIGN-debug-apk` untuk download.
7. File yang didownload berupa `.zip` kecil isi APK — extract, lalu kamu punya
   `app-debug.apk`. Transfer/buka langsung di HP, install (izinkan "install dari sumber
   tidak dikenal" sekali kalau diminta).

**Kalau kamu sudah punya repo dari sebelumnya**: cukup ganti/timpa file zip lama dengan
`SOVEREIGN-Android-Widget-v40.5.zip` ini (hapus zip lama, upload yang baru dengan
nama yang sama persis), dan update isi `build-apk.yml` sesuai versi di bagian akhir
panduan ini (ada perubahan nama file yang di-extract).

Setiap kali kamu nanti edit kode (misal lewat GitHub web editor langsung di HP, tekan
tombol pensil di file), commit perubahan, dan GitHub Actions otomatis build ulang APK
baru untuk kamu — semua dari HP, tanpa laptop, tanpa install apapun di HP selain app
GitHub (opsional) dan file manager.

> Catatan: APK yang dihasilkan ini adalah **debug build** — sudah bisa diinstall dan
> dipakai normal di HP kamu sendiri, hanya saja kalau suatu saat mau publish ke Google
> Play butuh proses signing release tambahan (di luar scope kebutuhan kamu sekarang).

---

## Alternatif kalau nanti kamu pakai laptop juga

## Apa yang sudah jadi
- `MainActivity` — WebView yang me-load `index.html` PWA kamu apa adanya dari folder `assets/`.
- 4 `AppWidgetProvider` (Widget5x2, Widget5x3, Widget3x2, Widget2x2) yang menampilkan data
  portfolio secara live, dengan desain gelap-gold konsisten dengan branding SOVEREIGN.
- `PriceUpdateWorker` — job WorkManager yang fetch harga BTC, Gold, BBRI, BMRI, kurs USD/IDR
  tiap **15 menit** di background, langsung dari API (Binance, gold-api.com, Yahoo Finance) —
  TANPA proxy CORS, karena app native tidak terkena CORS restriction seperti browser.
- Jembatan JS↔Kotlin (`SovereignBridge`) yang membaca `localStorage` PWA kamu
  (`sovereign_portfolio` dan `sovereign_prices`) setiap kali app dibuka/diminimize, supaya
  widget selalu pakai data yang SAMA PERSIS dengan yang kamu lihat di PWA — tidak ada
  duplikasi input atau drift data.

## Yang HARUS kamu lakukan sebelum build (sekali saja)
1. **Install Android Studio** (gratis): https://developer.android.com/studio
2. **Buka folder ini** (`sovereign-android/`) sebagai project di Android Studio
   (File → Open → pilih folder `sovereign-android`).
3. Android Studio akan minta sinkronisasi Gradle otomatis — biarkan proses ini berjalan
   (akan download Gradle wrapper jar yang sengaja tidak saya sertakan karena sandbox saya
   tidak punya akses internet).
4. Tunggu sampai "Gradle sync finished" muncul di bawah.

## Cara build APK
**Opsi cepat (debug, langsung install ke HP):**
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
APK akan muncul di `app/build/outputs/apk/debug/app-debug.apk`. Transfer ke HP, install
(perlu izinkan "install dari sumber tidak dikenal" sekali).

**Opsi run langsung dari Android Studio:**
- Sambungkan HP via USB (aktifkan USB Debugging di Developer Options), atau pakai emulator.
- Klik tombol ▶ Run di Android Studio.

## Cara pasang widget di homescreen
1. Install & buka app SOVEREIGN sekali. Saat dibuka, akan muncul dialog sistem minta
   izin **"Allow background activity"** / **"Izinkan tanpa batasan"** — ketuk **Allow**.
   Ini penting supaya update data widget tidak dibekukan OS (terutama di HP Xiaomi,
   Oppo, Vivo, Samsung yang punya battery management agresif).
2. Tunggu sekitar 10-15 detik di dalam app — di balik layar app sedang fetch data
   harga BTC/Gold/BBRI/BMRI dan menyimpannya untuk dipakai widget.
3. Long-press di homescreen kosong → **Widgets**.
4. Cari **SOVEREIGN** → akan muncul 4 varian: 5x2, 5x3, 3x2, 2x2.
5. Drag salah satu (atau semua) ke homescreen, resize sesuai grid yang kamu mau.
   Widget seharusnya **langsung terisi data nyata** (bukan `--`) dalam beberapa detik
   setelah didrop, karena widget otomatis fetch data sendiri saat pertama dipasang.

**Kalau widget masih kosong setelah ~10 detik**: tap ikon ⟳ di pojok widget itu untuk
fetch manual. Kalau masih kosong setelah itu, cek Settings → Apps → SOVEREIGN →
Battery, pastikan statusnya **"Unrestricted"/"Tidak dibatasi"**, bukan "Optimized".

## Update data widget
- Otomatis tiap 15 menit di background (battery-friendly, sesuai standar Android).
- Manual: tap ikon ⟳ di pojok widget kapan saja.
- Tap badan widget (selain ikon refresh) akan membuka app SOVEREIGN penuh.

## Kalau mau ubah portfolio (lot BBRI/BMRI, BTC owned, dst)
Tetap edit seperti biasa di halaman **Input** PWA SOVEREIGN (di dalam app). Begitu kamu
`saveToStorage()`, dan app di-minimize/dibuka lagi, data otomatis tersinkron ke widget lewat
bridge — kamu tidak perlu edit apapun di kode Android.

## Struktur project
```
app/src/main/
├── assets/                     ← isi PWA v40 kamu, copy 1:1, TIDAK DIUBAH
│   ├── index.html
│   ├── sw.js
│   ├── manifest.json
│   ├── icon-192.png
│   └── icon-512.png
├── java/com/sovereign/portfolio/
│   ├── MainActivity.kt          ← WebView wrapper + JS bridge
│   ├── Models.kt                 ← data class harga & portfolio + formatter Rp/USD
│   ├── Store.kt                  ← SharedPreferences persist
│   ├── NetworkFetcher.kt          ← fetch BTC/Gold/BBRI/BMRI langsung (no proxy)
│   ├── PortfolioCalculator.kt    ← net worth, status sistem 100/120%, dividend
│   ├── PriceUpdateWorker.kt      ← WorkManager job tiap 15 menit
│   ├── WorkScheduler.kt          ← helper schedule/trigger worker
│   ├── WidgetUpdater.kt          ← render RemoteViews ke 4 ukuran widget
│   └── widgets/
│       ├── BaseSovereignWidgetProvider.kt
│       ├── Widget5x2Provider.kt
│       ├── Widget5x3Provider.kt
│       ├── Widget3x2Provider.kt
│       └── Widget2x2Provider.kt
└── res/
    ├── layout/widget_5x2.xml, widget_5x3.xml, widget_3x2.xml, widget_2x2.xml
    ├── xml/widget_5x2_info.xml, dst.        ← definisi grid size & update period
    ├── drawable/                            ← background gradient, ikon BTC/Gold/Stock/trend
    └── values/colors.xml, strings.xml, themes.xml
```

## Catatan teknis penting
- **Lockscreen widget**: sesuai diskusi, fitur ini di-skip karena Android 5+ sudah
  menghapus native lockscreen widget grid dari OS — tidak ada API publik untuk itu lagi.
- **Kenapa app native bisa fetch langsung tanpa proxy CORS** seperti yang PWA kamu lakukan
  (allorigins, corsproxy, dst)? Karena CORS adalah pembatasan browser, bukan pembatasan
  server. App Android pakai HTTP client native (`HttpURLConnection`), jadi bisa hit API
  manapun langsung tanpa hambatan CORS.
- **Interval 15 menit** adalah batas minimum resmi `PeriodicWorkRequest` di Android — kalau
  diset lebih kecil, sistem akan otomatis clamp ke 15 menit juga. Ini sudah paling optimal.
- Ikon launcher (`ic_launcher.png`) saat ini memakai `icon-192.png` PWA kamu sebagai
  placeholder sederhana. Kalau mau ikon adaptive yang lebih rapi, klik kanan `res` →
  **New → Image Asset** di Android Studio dan upload ulang source image-nya.

## Generate APK untuk dibagikan / dipasang tanpa kabel
Setelah build pertama berhasil, kamu bisa lanjut ke **Build → Generate Signed Bundle / APK**
untuk membuat APK release yang siap dibagikan ke HP lain tanpa USB, tinggal kirim file
`.apk`-nya via WhatsApp/Drive lalu install di HP Android manapun.

## Isi file `.github/workflows/build-apk.yml` (copy-paste persis ini)

Kalau kamu pakai metode GitHub Actions tanpa laptop, ini isi lengkap yang harus
dipaste ke file `.github/workflows/build-apk.yml` di repo kamu:

```yaml
name: Build SOVEREIGN APK

on:
  push:
    branches: [main]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Extract project zip
        run: |
          unzip -o SOVEREIGN-Android-Widget-v40.5.zip -d extracted
          ls -la extracted

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - uses: actions/cache@v4
        with:
          path: |
            ~/.gradle/caches
            ~/.gradle/wrapper
          key: gradle-${{ hashFiles('extracted/**/*.gradle*') }}

      - name: Generate Gradle Wrapper
        working-directory: extracted
        run: gradle wrapper --gradle-version 8.4

      - name: Beri izin eksekusi gradlew
        working-directory: extracted
        run: chmod +x ./gradlew

      - name: Build Debug APK
        working-directory: extracted
        run: ./gradlew assembleDebug --no-daemon

      - uses: actions/upload-artifact@v4
        with:
          name: SOVEREIGN-debug-apk
          path: extracted/app/build/outputs/apk/debug/app-debug.apk
```

**Penting**: baris `unzip -o SOVEREIGN-Android-Widget-v40.5.zip` harus PERSIS
sama dengan nama file zip yang kamu upload ke repo. Kalau kamu rename file zip-nya
saat upload (misal GitHub otomatis menambahkan `(1)` karena ada file dengan nama sama),
sesuaikan baris itu dengan nama file yang sebenarnya muncul di repo kamu.
