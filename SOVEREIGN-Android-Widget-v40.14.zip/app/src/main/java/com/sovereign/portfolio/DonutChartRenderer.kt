package com.sovereign.portfolio

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * Replikasi PIXEL-LOGIC persis dari fungsi `updateAllocUI()` di index.html PWA
 * (SVG "pizzaSvg", lihat baris ~2781-2884) — TIDAK ditebak ulang, semua radius
 * proporsi, sudut mulai, arah, gap antar slice, dan warna disalin dari sumber
 * yang sama. RemoteViews tidak mendukung custom View/Canvas di layout XML,
 * jadi chart digambar sebagai Bitmap di sini lalu dipasang ke ImageView lewat
 * `RemoteViews.setImageViewBitmap()` (BaseProvider/WidgetUpdater).
 *
 * Dua ring konsentris per aset (sama seperti PWA):
 *   - Ring LUAR = TARGET%  → warna dim/transparan (alpha ~45%)
 *   - Ring DALAM = AKTUAL% → warna solid + sedikit glow (blur shadow halus)
 * Urutan render: Saham → Bitcoin → Emas → VTI/S&P, mulai dari jam 12 (atas),
 * searah jarum jam — identik dengan array `ASSETS` di PWA.
 */
object DonutChartRenderer {

    /** Render donut chart Target-vs-Aktual ke Bitmap persegi (size x size px). */
    fun render(slices: List<PortfolioCalculator.AllocSlice>, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val cx = size / 2f
        val cy = size / 2f
        // Radius proporsi persis seperti PWA (viewBox 200x200, cx=cy=100):
        // RoOut=92 RoIn=72 (target ring), RiOut=67 RiIn=47 (actual ring), hole=42
        val scale = size / 200f
        val roOut = 92f * scale
        val roIn = 72f * scale
        val riOut = 67f * scale
        val riIn = 47f * scale
        val holeR = 42f * scale

        val gapDeg = Math.toDegrees(0.018).toFloat() // GAP = 0.018 rad di PWA

        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            maskFilter = BlurMaskFilter(3.5f * scale, BlurMaskFilter.Blur.NORMAL)
        }

        var cumStartDeg = -90f // mulai dari atas (jam 12), sama seperti cumT = -Math.PI/2

        for (slice in slices) {
            val color = Color.parseColor(slice.colorHex)
            val targetSweep = slice.targetPct / 100f * 360f
            val actualSweep = slice.aktualPct / 100f * 360f

            // ── Outer ring = TARGET (dim, alpha 0.45 — replika rgba(...,.45))
            if (targetSweep > gapDeg) {
                ringPaint.color = withAlpha(color, 0.45f)
                drawRingSlice(canvas, cx, cy, roOut, roIn, cumStartDeg + gapDeg / 2f, targetSweep - gapDeg, ringPaint)
            }

            // ── Inner ring = AKTUAL (solid + glow halus, replika opacity .95 + feDropShadow)
            if (actualSweep > gapDeg) {
                glowPaint.color = withAlpha(color, 0.55f)
                drawRingSlice(canvas, cx, cy, riOut, riIn, cumStartDeg + gapDeg / 2f, actualSweep - gapDeg, glowPaint)

                ringPaint.color = withAlpha(color, 0.95f)
                drawRingSlice(canvas, cx, cy, riOut, riIn, cumStartDeg + gapDeg / 2f, actualSweep - gapDeg, ringPaint)
            }

            // ── Label TARGET% di tengah ring luar (kalau cukup besar untuk ditulis)
            if (targetSweep > 11f) {
                val midDeg = cumStartDeg + targetSweep / 2f
                val labelR = (roOut + roIn) / 2f
                drawLabel(canvas, cx, cy, labelR, midDeg, "${slice.targetPct}%", 8.2f * scale)
            }

            // ── Label AKTUAL% di tengah ring dalam
            if (actualSweep > 11f && slice.aktualPct > 5) {
                val midDeg = cumStartDeg + actualSweep / 2f
                val labelR = (riOut + riIn) / 2f
                drawLabel(canvas, cx, cy, labelR, midDeg, "${slice.aktualPct}%", 7.7f * scale)
            }

            cumStartDeg += targetSweep
        }

        // ── Lubang tengah donut (replika <circle r="42" fill="#111">)
        val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#111111") }
        canvas.drawCircle(cx, cy, holeR, holePaint)

        return bmp
    }

    private fun withAlpha(color: Int, alpha: Float): Int {
        val a = (alpha * 255).toInt().coerceIn(0, 255)
        return Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))
    }

    /** Gambar satu slice ring (anulus) dari radius r2 (dalam) ke r1 (luar), sudut dalam derajat. */
    private fun drawRingSlice(
        canvas: Canvas,
        cx: Float, cy: Float,
        rOuter: Float, rInner: Float,
        startDeg: Float, sweepDeg: Float,
        paint: Paint
    ) {
        if (sweepDeg <= 0f) return
        val path = android.graphics.Path()
        val outerRect = RectF(cx - rOuter, cy - rOuter, cx + rOuter, cy + rOuter)
        val innerRect = RectF(cx - rInner, cy - rInner, cx + rInner, cy + rInner)

        path.arcTo(outerRect, startDeg, sweepDeg, false)
        path.arcTo(innerRect, startDeg + sweepDeg, -sweepDeg, false)
        path.close()

        canvas.drawPath(path, paint)
    }

    private fun drawLabel(canvas: Canvas, cx: Float, cy: Float, r: Float, angleDeg: Float, text: String, textSizePx: Float) {
        val rad = Math.toRadians(angleDeg.toDouble())
        val lx = cx + r * Math.cos(rad).toFloat()
        val ly = cy + r * Math.sin(rad).toFloat()

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = textSizePx
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }
        // Offset vertikal supaya teks center-baseline mendekati titik (lx,ly)
        val baselineOffset = (paint.descent() + paint.ascent()) / 2f
        canvas.drawText(text, lx, ly - baselineOffset, paint)
    }
}
