package com.sovereign.portfolio

import android.content.Context
import android.content.SharedPreferences

object Store {
    private const val PREF_NAME = "sovereign_prefs"
    private const val KEY_PRICES = "key_prices"
    private const val KEY_PORTFOLIO = "key_portfolio"

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun savePrices(context: Context, snapshot: PriceSnapshot) {
        prefs(context).edit().putString(KEY_PRICES, snapshot.toJson()).apply()
    }

    fun loadPrices(context: Context): PriceSnapshot {
        val raw = prefs(context).getString(KEY_PRICES, null)
        return PriceSnapshot.fromJson(raw)
    }

    /**
     * Portfolio config disimpan sebagai field individual supaya mudah diedit
     * lewat SettingsActivity tanpa perlu re-serialize JSON penuh.
     */
    fun savePortfolio(context: Context, p: PortfolioConfig) {
        prefs(context).edit().apply {
            putFloat("btcOwned", p.btcOwned.toFloat())
            putFloat("emasGram", p.emasGram.toFloat())
            putInt("bbriLot", p.bbriLot)
            putFloat("bbriAvg", p.bbriAvg.toFloat())
            putInt("bmriLot", p.bmriLot)
            putFloat("bmriAvg", p.bmriAvg.toFloat())
            putFloat("vtiUsd", p.vtiUsd.toFloat())
            putFloat("vtiCostUsd", p.vtiCostUsd.toFloat())
            putFloat("spx500Usd", p.spx500Usd.toFloat())
            putFloat("spx500CostUsd", p.spx500CostUsd.toFloat())
            putFloat("slowLivingHarian", p.slowLivingHarian.toFloat())
            putFloat("bbriDps", p.bbriDps.toFloat())
            putFloat("bmriDps", p.bmriDps.toFloat())
            putFloat("btcTargetOwned", p.btcTargetOwned.toFloat())
            putFloat("emasTargetGram", p.emasTargetGram.toFloat())
            apply()
        }
    }

    fun loadPortfolio(context: Context): PortfolioConfig {
        val sp = prefs(context)
        val default = PortfolioConfig()
        return PortfolioConfig(
            btcOwned = sp.getFloat("btcOwned", default.btcOwned.toFloat()).toDouble(),
            emasGram = sp.getFloat("emasGram", default.emasGram.toFloat()).toDouble(),
            bbriLot = sp.getInt("bbriLot", default.bbriLot),
            bbriAvg = sp.getFloat("bbriAvg", default.bbriAvg.toFloat()).toDouble(),
            bmriLot = sp.getInt("bmriLot", default.bmriLot),
            bmriAvg = sp.getFloat("bmriAvg", default.bmriAvg.toFloat()).toDouble(),
            vtiUsd = sp.getFloat("vtiUsd", default.vtiUsd.toFloat()).toDouble(),
            vtiCostUsd = sp.getFloat("vtiCostUsd", default.vtiCostUsd.toFloat()).toDouble(),
            spx500Usd = sp.getFloat("spx500Usd", default.spx500Usd.toFloat()).toDouble(),
            spx500CostUsd = sp.getFloat("spx500CostUsd", default.spx500CostUsd.toFloat()).toDouble(),
            slowLivingHarian = sp.getFloat("slowLivingHarian", default.slowLivingHarian.toFloat()).toDouble(),
            bbriDps = sp.getFloat("bbriDps", default.bbriDps.toFloat()).toDouble(),
            bmriDps = sp.getFloat("bmriDps", default.bmriDps.toFloat()).toDouble(),
            btcTargetOwned = sp.getFloat("btcTargetOwned", default.btcTargetOwned.toFloat()).toDouble(),
            emasTargetGram = sp.getFloat("emasTargetGram", default.emasTargetGram.toFloat()).toDouble()
        )
    }
}
