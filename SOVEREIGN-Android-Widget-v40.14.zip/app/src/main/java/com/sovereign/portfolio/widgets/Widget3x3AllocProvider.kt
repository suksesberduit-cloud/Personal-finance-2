package com.sovereign.portfolio.widgets

/** Widget ukuran 3x3 (ke-7) — donut chart Target vs Aktual untuk 4 aset
 * (Saham/Bitcoin/Emas/VTI-S&P), replikasi visual persis diagram
 * "ALOKASI PORTOFOLIO" Tab Dashboard PWA (ring luar=TARGET, ring dalam=AKTUAL). */
class Widget3x3AllocProvider : BaseSovereignWidgetProvider()
