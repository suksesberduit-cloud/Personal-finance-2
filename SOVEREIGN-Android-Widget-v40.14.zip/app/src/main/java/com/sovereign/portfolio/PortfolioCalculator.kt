package com.sovereign.portfolio

/**
 * Replikasi logic kalkulasi inti dari index.html SOVEREIGN PWA:
 * getSLOW(), getTARGET120(), updateSistemStatus(), updateSlowLivingTracker(),
 * simulasi kekurangan lot BBRI/BMRI, dan net worth aggregator.
 */
object PortfolioCalculator {

    data class SistemStatus(
        val pct: Double,
        val statusEmoji: String,   // 🔴 🟡 🟢
        val colorHex: String       // warna sesuai threshold PWA
    )

    data class Snapshot(
        val netWorth: Double,
        val btcValueIdr: Double,
        val goldValueIdr: Double,
        val sahamValueIdr: Double,
        val vtiSpxValueIdr: Double,
        val dividenTotalThn: Double,
        val sistem: SistemStatus,
        val btcOwned: Double,
        val btcTarget: Double
    )

    /** Replika persis updateSlowLivingTracker() — hari terbayar dividen per bulan (skala 30 hari) */
    data class SlowLivingTracker(
        val daysPaid: Int,      // 0-30
        val daysWork: Int,      // 30 - daysPaid
        val pctThn: Double,     // progress tahunan, dicap maksimal 100%
        val divHarian: Double,
        val targetHarian: Double
    )

    /** Replika persis simulasi iteratif kekurangan lot BBRI/BMRI di PWA (baris ~3095-3156 index.html) */
    data class KekuranganLot(
        val sudahCukup: Boolean,
        val bbriTambahLot: Int,
        val bmriTambahLot: Int,
        val danaBbri: Double,
        val danaBmri: Double,
        val totalDana: Double,
        val pctBbriFinal: Int,
        val pctBmriFinal: Int,
        val divBulanFinal: Double
    )

    /** Satu baris progress di widget "Progress Achieve Dream" (5x2 baru) */
    data class DreamItem(
        val label: String,
        val pct: Double,        // 0-100, sudah di-cap
        val detail: String      // teks kecil kanan, misal "0.0056/0.2 BTC" atau "+12.4%"
    )

    data class DreamProgress(
        val dividen: DreamItem,
        val btc: DreamItem,
        val emas: DreamItem,
        val vtiSpx: DreamItem
    )

    /**
     * Replika persis 4 angka Aktual% dari updateAllocUI() PWA (basis 4 aset:
     * saham+btc+emas+index, Math.round per aset) PLUS 4 angka Target% tetap
     * (TARGET_ALLOC PWA: saham:50, btc:25, emas:15, index:10). Dipakai widget
     * donut 3x3 (ke-7) untuk menggambar ring TARGET (luar) vs AKTUAL (dalam)
     * persis seperti diagram "ALOKASI PORTOFOLIO" Tab Dashboard PWA.
     */
    data class AllocSlice(
        val key: String,       // "saham" | "btc" | "emas" | "index" — urutan render searah jarum jam dari atas
        val label: String,
        val targetPct: Int,
        val aktualPct: Int,
        val colorHex: String   // warna solid persis ALLOC_COLORS di PWA
    )

    fun calcAllocSlices(prices: PriceSnapshot, p: PortfolioConfig): List<AllocSlice> {
        val snap = calculate(prices, p)
        val total = snap.netWorth

        fun aktual(value: Double): Int =
            if (total > 0) Math.round((value / total) * 100).toInt() else 0

        return listOf(
            AllocSlice("saham", "Saham ID", TARGET_SAHAM_PCT.toInt(), aktual(snap.sahamValueIdr), "#22C55E"),
            AllocSlice("btc", "Bitcoin", TARGET_BTC_PCT.toInt(), aktual(snap.btcValueIdr), "#F97316"),
            AllocSlice("emas", "Emas", TARGET_EMAS_PCT.toInt(), aktual(snap.goldValueIdr), "#C9A84C"),
            AllocSlice("index", "VTI/S&P", TARGET_VTI_SPX_PCT.toInt(), aktual(snap.vtiSpxValueIdr), "#3B82F6")
        )
    }

    fun getSlow(p: PortfolioConfig): Double = p.slowLivingHarian * 365.0

    fun getTarget120(p: PortfolioConfig): Double = getSlow(p) * 1.2

    fun calcSistemStatus(p: PortfolioConfig, totalDiv: Double): SistemStatus {
        val slow = getSlow(p)
        if (slow <= 0) return SistemStatus(0.0, "⚪", "#8A8A85")
        val pct = (totalDiv / slow) * 100

        return when {
            pct < 100 -> SistemStatus(pct, "🔴", "#EF4444")
            pct < 120 -> SistemStatus(pct, "🟡", "#FBBF24")
            else -> SistemStatus(pct, "🟢", "#22C55E")
        }
    }

    /**
     * Replika persis updateSlowLivingTracker(): rasio dividen harian terhadap
     * target harian dikonversi jadi "hari terbayar" dalam skala 30 hari/bulan.
     */
    fun calcSlowLivingTracker(p: PortfolioConfig, totalDivTahunan: Double): SlowLivingTracker {
        val divHarian = totalDivTahunan / 365.0
        val targetHarian = if (p.slowLivingHarian > 0) p.slowLivingHarian else 150000.0
        val targetTahunan = getSlow(p)

        val rasio = if (targetHarian > 0) divHarian / targetHarian else 0.0
        val daysPaid = Math.min(30, Math.floor(rasio * 30).toInt())
        val daysWork = 30 - daysPaid
        val pctThn = if (targetTahunan > 0) {
            Math.min((totalDivTahunan / targetTahunan) * 100, 100.0)
        } else 0.0

        return SlowLivingTracker(
            daysPaid = daysPaid,
            daysWork = daysWork,
            pctThn = pctThn,
            divHarian = divHarian,
            targetHarian = targetHarian
        )
    }

    /**
     * Replika persis simulasi iteratif kekurangan lot di PWA: tambah 1 lot
     * setiap iterasi ke sisi yang nilai investasinya (avg price * lot) lebih
     * kecil, sampai total dividen tahunan >= target SLOW. Dana dihitung pakai
     * harga LIVE (bukan harga average beli).
     */
    fun calcKekuranganLot(
        p: PortfolioConfig,
        bbriHargaLive: Double,
        bmriHargaLive: Double
    ): KekuranganLot? {
        val slow = getSlow(p)
        val totalDivSekarang = (p.bbriDps * p.bbriLot * 100.0) + (p.bmriDps * p.bmriLot * 100.0)
        val surplus = totalDivSekarang - slow

        if (surplus >= 0) {
            return KekuranganLot(
                sudahCukup = true,
                bbriTambahLot = 0, bmriTambahLot = 0,
                danaBbri = 0.0, danaBmri = 0.0, totalDana = 0.0,
                pctBbriFinal = 0, pctBmriFinal = 0, divBulanFinal = totalDivSekarang / 12.0
            )
        }

        if (bbriHargaLive <= 0 || bmriHargaLive <= 0) return null

        val bbriAvgHarga = if (p.bbriAvg > 0) p.bbriAvg else bbriHargaLive
        val bmriAvgHarga = if (p.bmriAvg > 0) p.bmriAvg else bmriHargaLive

        var simBbri = p.bbriLot
        var simBmri = p.bmriLot
        var iter = 0
        while ((p.bbriDps * simBbri * 100.0 + p.bmriDps * simBmri * 100.0) < slow && iter < 20000) {
            val invBbri = simBbri * bbriAvgHarga
            val invBmri = simBmri * bmriAvgHarga
            if (invBbri <= invBmri) simBbri++ else simBmri++
            iter++
        }

        val bbriTambah = simBbri - p.bbriLot
        val bmriTambah = simBmri - p.bmriLot

        val danaBbri = bbriTambah * bbriHargaLive * 100.0
        val danaBmri = bmriTambah * bmriHargaLive * 100.0
        val totalDana = danaBbri + danaBmri

        val bbriInvFinal = simBbri * bbriAvgHarga * 100.0
        val bmriInvFinal = simBmri * bmriAvgHarga * 100.0
        val totInvFinal = bbriInvFinal + bmriInvFinal
        val pctBbriF = if (totInvFinal > 0) Math.round(bbriInvFinal / totInvFinal * 100).toInt() else 0
        val pctBmriF = if (totInvFinal > 0) Math.round(bmriInvFinal / totInvFinal * 100).toInt() else 0

        val divFinal = p.bbriDps * simBbri * 100.0 + p.bmriDps * simBmri * 100.0

        return KekuranganLot(
            sudahCukup = false,
            bbriTambahLot = bbriTambah,
            bmriTambahLot = bmriTambah,
            danaBbri = danaBbri,
            danaBmri = danaBmri,
            totalDana = totalDana,
            pctBbriFinal = pctBbriF,
            pctBmriFinal = pctBmriF,
            divBulanFinal = divFinal / 12.0
        )
    }

    /**
     * Hitung snapshot lengkap portfolio dari harga live + config.
     * kursUsd dipakai untuk convert USD->IDR (BTC, Gold, VTI/SPX dalam USD).
     */
    fun calculate(prices: PriceSnapshot, p: PortfolioConfig): Snapshot {
        val kurs = if (prices.kursUsd > 0) prices.kursUsd else 16400.0

        val btcValueIdr = (prices.btcUsd ?: 0.0) * p.btcOwned * kurs
        // Gold price API biasanya per troy ounce; PWA pakai konversi gram (1 troy oz = 31.1035g)
        val goldPerGramUsd = (prices.goldUsd ?: 0.0) / 31.1034768
        val goldValueIdr = goldPerGramUsd * p.emasGram * kurs

        val bbriValueIdr = (prices.bbriPrice ?: 0.0) * p.bbriLot * 100.0
        val bmriValueIdr = (prices.bmriPrice ?: 0.0) * p.bmriLot * 100.0
        val sahamValueIdr = bbriValueIdr + bmriValueIdr

        val vtiSpxValueIdr = (p.vtiUsd + p.spx500Usd) * kurs

        val netWorth = btcValueIdr + goldValueIdr + sahamValueIdr + vtiSpxValueIdr

        val dividenTotal = (p.bbriDps * p.bbriLot * 100.0) + (p.bmriDps * p.bmriLot * 100.0)
        val sistem = calcSistemStatus(p, dividenTotal)

        return Snapshot(
            netWorth = netWorth,
            btcValueIdr = btcValueIdr,
            goldValueIdr = goldValueIdr,
            sahamValueIdr = sahamValueIdr,
            vtiSpxValueIdr = vtiSpxValueIdr,
            dividenTotalThn = dividenTotal,
            sistem = sistem,
            btcOwned = p.btcOwned,
            btcTarget = p.btcTargetOwned
        )
    }

    /**
     * Progress menuju 4 "dream" yang dikejar user: dividen slow living, BTC,
     * emas, dan VTI/S&P500. Dipakai widget 5x2 baru — sengaja TIDAK menyertakan
     * net worth (atas permintaan user, dianggap kurang relevan ditampilkan).
     *
     * Definisi progress (v40.13, REVISI FINAL — mencerminkan diagram
     * "ALOKASI PORTOFOLIO Target vs Aktual" di Tab Dashboard PWA persis):
     * - Dividen: tetap progress tahunan terhadap target SLOW (pctThn).
     * - Saham/BTC/Emas/VTI-SPX: PWA (index.html, fungsi updateAllocUI())
     *   menghitung "Aktual%" = nilai aset / total 4 aset * 100, dibandingkan
     *   ke TARGET_ALLOC tetap {saham:50, btc:25, emas:15, index:10}.
     *   Progress bar widget = Aktual% / Target% * 100 — >100% berarti
     *   OVER-alokasi (porsi aset itu melebihi target rencana), bukan masih
     *   kurang. TIDAK ada input manual sama sekali (totalInvestRencana dari
     *   v40.12 sudah TIDAK DIPAKAI lagi — net worth aktual dari live price
     *   yang jadi basis, otomatis, sama seperti PWA).
     */
    private const val TARGET_SAHAM_PCT = 50.0
    private const val TARGET_BTC_PCT = 25.0
    private const val TARGET_EMAS_PCT = 15.0
    private const val TARGET_VTI_SPX_PCT = 10.0

    fun calcDreamProgress(prices: PriceSnapshot, p: PortfolioConfig): DreamProgress {
        val dividenTotal = (p.bbriDps * p.bbriLot * 100.0) + (p.bmriDps * p.bmriLot * 100.0)
        val divTracker = calcSlowLivingTracker(p, dividenTotal)
        val dividen = DreamItem(
            label = "DIVIDEN",
            pct = divTracker.pctThn,
            detail = "${divTracker.daysPaid}/30 hari"
        )

        val snap = calculate(prices, p)
        val total = snap.netWorth

        // Aktual% persis sama formula seperti updateAllocUI() di PWA (Math.round, basis 4 aset)
        val btcAktualPct = if (total > 0) Math.round((snap.btcValueIdr / total) * 100).toDouble() else 0.0
        val emasAktualPct = if (total > 0) Math.round((snap.goldValueIdr / total) * 100).toDouble() else 0.0
        val vtiSpxAktualPct = if (total > 0) Math.round((snap.vtiSpxValueIdr / total) * 100).toDouble() else 0.0

        // Progress bar = aktual/target * 100 — bisa lewat 100% (over-alokasi), di-cap untuk tampilan bar saja
        val btcProgressPct = if (TARGET_BTC_PCT > 0) (btcAktualPct / TARGET_BTC_PCT) * 100.0 else 0.0
        val btc = DreamItem(
            label = "BTC",
            pct = Math.min(btcProgressPct, 100.0),
            detail = "${btcAktualPct.toInt()}%/${TARGET_BTC_PCT.toInt()}%"
        )

        val emasProgressPct = if (TARGET_EMAS_PCT > 0) (emasAktualPct / TARGET_EMAS_PCT) * 100.0 else 0.0
        val emas = DreamItem(
            label = "EMAS",
            pct = Math.min(emasProgressPct, 100.0),
            detail = "${emasAktualPct.toInt()}%/${TARGET_EMAS_PCT.toInt()}%"
        )

        val vtiSpxProgressPct = if (TARGET_VTI_SPX_PCT > 0) (vtiSpxAktualPct / TARGET_VTI_SPX_PCT) * 100.0 else 0.0
        val vtiSpx = DreamItem(
            label = "VTI/SPX",
            pct = Math.min(vtiSpxProgressPct, 100.0),
            detail = "${vtiSpxAktualPct.toInt()}%/${TARGET_VTI_SPX_PCT.toInt()}%"
        )

        return DreamProgress(dividen = dividen, btc = btc, emas = emas, vtiSpx = vtiSpx)
    }
}
