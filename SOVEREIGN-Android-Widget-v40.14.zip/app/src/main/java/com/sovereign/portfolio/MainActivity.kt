package com.sovereign.portfolio

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val activityScope = CoroutineScope(Dispatchers.Main)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true        // wajib — PWA pakai localStorage
            allowFileAccess = true
            allowContentAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        // Bridge JS <-> Kotlin: PWA bisa panggil window.SovereignBridge.syncPortfolio(json)
        // setiap kali user simpan perubahan input portfolio, supaya widget ikut update.
        webView.addJavascriptInterface(SovereignBridge(this), "SovereignBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Setelah halaman selesai load, baca localStorage portfolio & prices,
                // lalu sinkronkan ke SharedPreferences Android untuk widget.
                injectSyncScript()
            }
        }
        webView.webChromeClient = WebChromeClient()

        // Load file PWA dari assets (index.html, sw.js, manifest.json, ikon di-copy ke assets saat build)
        webView.loadUrl("file:///android_asset/index.html")

        // Pastikan worker periodic 15 menit terdaftar untuk update widget selanjutnya
        WorkScheduler.schedulePeriodic(this)

        // Fetch data native langsung sekali di sini (bukan cuma andalkan WorkManager
        // yang bisa ditunda sistem) — supaya begitu user buka app lalu langsung pasang
        // widget, cache SUDAH terisi data nyata, tidak perlu menunggu worker 15 menit.
        fetchFreshDataInBackground()

        // Minta pembebasan battery optimization — krusial supaya WorkManager periodic
        // tetap jalan konsisten di HP dengan battery management agresif (Xiaomi MIUI,
        // Oppo ColorOS, Vivo FuntouchOS, Samsung), yang secara default sering membekukan
        // background work app yang baru di-install.
        requestBatteryOptimizationExemption()
    }

    private fun fetchFreshDataInBackground() {
        activityScope.launch {
            try {
                val fresh = withContext(Dispatchers.IO) {
                    NetworkFetcher.fetchAllWithTimeout(12000)
                }
                val cached = Store.loadPrices(this@MainActivity)
                val merged = fresh.mergeWithFallback(cached)
                Store.savePrices(this@MainActivity, merged)
                WidgetUpdater.updateAll(this@MainActivity)
            } catch (e: Exception) {
                // Diamkan — tidak kritikal, worker periodik akan coba lagi nanti
            }
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryOptimizationExemption() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            val packageName = packageName
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        } catch (e: Exception) {
            // Beberapa OEM/ROM custom tidak mendukung intent ini — diamkan,
            // tidak kritikal untuk fungsi utama app.
        }
    }

    /**
     * Inject script kecil yang membaca localStorage `sovereign_portfolio` dan
     * `sovereign_prices`, lalu kirim ke Kotlin lewat bridge supaya widget bisa
     * pakai data yang SAMA PERSIS dengan yang ditampilkan di PWA — tidak ada
     * duplikasi sumber data atau drift antara app dan widget.
     */
    private fun injectSyncScript() {
        val js = """
            (function() {
                try {
                    var portfolio = localStorage.getItem('sovereign_portfolio');
                    var prices = localStorage.getItem('sovereign_prices');
                    if (window.SovereignBridge) {
                        if (portfolio) window.SovereignBridge.syncPortfolio(portfolio);
                        if (prices) window.SovereignBridge.syncPrices(prices);
                    }
                } catch (e) {}
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    override fun onPause() {
        super.onPause()
        // Sinkron sekali lagi saat app diminimize, menangkap perubahan input terbaru
        injectSyncScript()
    }

    override fun onDestroy() {
        super.onDestroy()
        activityScope.cancel()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    /** Bridge object yang diekspos ke window.SovereignBridge di JavaScript */
    inner class SovereignBridge(private val activity: MainActivity) {

        @JavascriptInterface
        fun syncPortfolio(json: String) {
            try {
                val o = org.json.JSONObject(json)
                // Field manual yang HANYA dikelola di Android (tidak pernah dikirim PWA,
                // misal lewat SettingsActivity di masa depan), WAJIB di-preserve dari
                // Store yang sudah ada — bukan ditimpa balik ke default Kotlin setiap
                // kali WebView sync jalan (terjadi setiap app dibuka/dipause).
                val existing = Store.loadPortfolio(activity)
                val config = PortfolioConfig(
                    btcOwned = o.optDouble("btcOwned", 0.0056),
                    emasGram = o.optDouble("emasGram", 0.0),
                    bbriLot = o.optInt("bbriLot", 516),
                    bbriAvg = o.optDouble("bbriAvg", 4200.0),
                    bmriLot = o.optInt("bmriLot", 309),
                    bmriAvg = o.optDouble("bmriAvg", 5800.0),
                    vtiUsd = o.optDouble("vtiUsd", 0.0),
                    vtiCostUsd = o.optDouble("vtiCostUsd", existing.vtiCostUsd),
                    spx500Usd = o.optDouble("spx500Usd", 0.0),
                    spx500CostUsd = o.optDouble("spx500CostUsd", existing.spx500CostUsd),
                    slowLivingHarian = o.optDouble("slowLivingHarian", 150000.0),
                    bbriDps = o.optDouble("bbriDps", 346.00),
                    bmriDps = o.optDouble("bmriDps", 476.95),
                    btcTargetOwned = o.optDouble("btcTargetOwned", existing.btcTargetOwned),
                    emasTargetGram = o.optDouble("emasTargetGram", existing.emasTargetGram)
                )
                Store.savePortfolio(activity, config)
                WidgetUpdater.updateAll(activity)
            } catch (e: Exception) { /* ignore malformed json */ }
        }

        @JavascriptInterface
        fun syncPrices(json: String) {
            try {
                val o = org.json.JSONObject(json)
                val snapshot = PriceSnapshot(
                    btcUsd = o.optDouble("btcUsd").takeIf { !it.isNaN() },
                    btcChg = o.optDouble("btcChg").takeIf { !it.isNaN() },
                    goldUsd = o.optDouble("goldUsd").takeIf { !it.isNaN() },
                    goldChg = o.optDouble("goldChg").takeIf { !it.isNaN() },
                    bbriPrice = o.optDouble("bbriPrice").takeIf { !it.isNaN() },
                    bbriChg = o.optDouble("bbriChg").takeIf { !it.isNaN() },
                    bmriPrice = o.optDouble("bmriPrice").takeIf { !it.isNaN() },
                    bmriChg = o.optDouble("bmriChg").takeIf { !it.isNaN() },
                    kursUsd = o.optDouble("kursUsd", 16400.0),
                    savedAt = System.currentTimeMillis()
                )
                Store.savePrices(activity, snapshot)
                WidgetUpdater.updateAll(activity)
            } catch (e: Exception) { /* ignore malformed json */ }
        }
    }
}
